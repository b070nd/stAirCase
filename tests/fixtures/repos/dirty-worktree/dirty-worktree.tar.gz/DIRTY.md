# This file is intentionally uncommitted.

It exists to make `git status` show a dirty working tree so that stAirCase
pre-flight tests can verify the dirty-tree refusal code path (E2E-009).
