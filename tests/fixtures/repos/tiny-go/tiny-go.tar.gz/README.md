# tiny-go

A minimal Go repository used as a stAirCase test fixture.

## Usage

```sh
go run . add 3 4   # → 7
go run . div 10 0  # → division by zero (exit 1)
```

## Tests

```sh
go test ./...
```
