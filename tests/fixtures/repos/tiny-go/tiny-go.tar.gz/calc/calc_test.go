package calc_test

import (
	"testing"

	"example.com/tiny/calc"
)

func TestAdd(t *testing.T)       { assertEqual(t, 5, calc.Add(2, 3)) }
func TestSub(t *testing.T)       { assertEqual(t, 1, calc.Sub(3, 2)) }
func TestMul(t *testing.T)       { assertEqual(t, 6, calc.Mul(2, 3)) }
func TestAbs_positive(t *testing.T) { assertEqual(t, 3, calc.Abs(3)) }
func TestAbs_negative(t *testing.T) { assertEqual(t, 3, calc.Abs(-3)) }
func TestMax(t *testing.T)       { assertEqual(t, 5, calc.Max(3, 5)) }
func TestMin(t *testing.T)       { assertEqual(t, 3, calc.Min(3, 5)) }
func TestClamp_in(t *testing.T)  { assertEqual(t, 4, calc.Clamp(4, 1, 9)) }
func TestClamp_lo(t *testing.T)  { assertEqual(t, 1, calc.Clamp(0, 1, 9)) }
func TestClamp_hi(t *testing.T)  { assertEqual(t, 9, calc.Clamp(99, 1, 9)) }
func TestSum(t *testing.T)       { assertEqual(t, 10, calc.Sum(1, 2, 3, 4)) }

func TestDiv_normal(t *testing.T) {
	got, err := calc.Div(10, 2)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	assertEqual(t, 5, got)
}

func TestDiv_by_zero(t *testing.T) {
	_, err := calc.Div(1, 0)
	if err != calc.ErrDivByZero {
		t.Fatalf("want ErrDivByZero, got %v", err)
	}
}

func assertEqual(t *testing.T, want, got int) {
	t.Helper()
	if want != got {
		t.Fatalf("want %d, got %d", want, got)
	}
}
