// Package calc provides simple arithmetic for stAirCase fixture testing.
package calc

import "errors"

// ErrDivByZero is returned when the divisor is zero.
var ErrDivByZero = errors.New("division by zero")

// Add returns a + b.
func Add(a, b int) int { return a + b }

// Sub returns a - b.
func Sub(a, b int) int { return a - b }

// Mul returns a * b.
func Mul(a, b int) int { return a * b }

// Div returns a / b.  Returns ErrDivByZero when b == 0.
func Div(a, b int) (int, error) {
	if b == 0 {
		return 0, ErrDivByZero
	}
	return a / b, nil
}

// Abs returns the absolute value of n.
func Abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}

// Max returns the larger of a and b.
func Max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// Min returns the smaller of a and b.
func Min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// Clamp returns n clamped to [lo, hi].
func Clamp(n, lo, hi int) int {
	return Max(lo, Min(hi, n))
}

// Sum returns the sum of all values.
func Sum(vals ...int) int {
	total := 0
	for _, v := range vals {
		total += v
	}
	return total
}
