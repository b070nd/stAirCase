// Command tiny is a minimal CLI that demonstrates the calc package.
// It is intentionally simple so stAirCase agents have a small surface to edit.
package main

import (
	"fmt"
	"os"
	"strconv"

	"example.com/tiny/calc"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: tiny <op> <a> <b>")
		fmt.Fprintln(os.Stderr, "  op: add sub mul div")
		os.Exit(1)
	}
	op := os.Args[1]
	a, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Fprintf(os.Stderr, "bad a: %v\n", err)
		os.Exit(1)
	}
	b, err := strconv.Atoi(os.Args[3])
	if err != nil {
		fmt.Fprintf(os.Stderr, "bad b: %v\n", err)
		os.Exit(1)
	}
	switch op {
	case "add":
		fmt.Println(calc.Add(a, b))
	case "sub":
		fmt.Println(calc.Sub(a, b))
	case "mul":
		fmt.Println(calc.Mul(a, b))
	case "div":
		result, err := calc.Div(a, b)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Println(result)
	default:
		fmt.Fprintf(os.Stderr, "unknown op: %s\n", op)
		os.Exit(1)
	}
}
